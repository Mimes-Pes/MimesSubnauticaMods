﻿using System;
using System.Text;
using Harmony;
using UnityEngine;
using SMLHelper.V2.Options;
using SMLHelper.V2.Utility;
using System.Reflection;


// Main mod.
namespace BetterHUDInfo  // Name of the mod.
{
    // Mod config to show in Q-Mod options.
    public static class Config
    {
        public static float FontSizeSliderValue;

        public static int InBaseDisplayChoiceIndex;
        public static int OutsideDisplayChoiceIndex;
        public static int InSubDisplayChoiceIndex;
        public static float MoveCompassSliderValue;
        public static bool SoftenHUDColourOutsideToggleValue;

        public static bool ShowOxygenToggleValue;

        public static bool ShowHullStrengthToggleValue;
        public static float HullLowerLimitSliderValue;
        public static float HullUpperLimitSliderValue;

        public static bool ShowCyclopsHullToggleValue;

        public static bool ShowBiomeToggleValue;

        public static bool ShowWaterTempToggleValue;
        public static float TempLowerLimitSliderValue;
        public static float TempUpperLimitSliderValue;

        public static bool ShowClockToggleValue;
        public static int ClockDisplayChoiceIndex;
        public static int ClockGameSystemChoiceIndex;

        public static bool ShowCoordsToggleValue;

        public static void Load()
        {
            FontSizeSliderValue = PlayerPrefs.GetFloat("FontSizeSlider", 30f);

            InBaseDisplayChoiceIndex = PlayerPrefs.GetInt("InBaseDisplayChoice", 1);
            OutsideDisplayChoiceIndex = PlayerPrefs.GetInt("OutsideDisplayChoice", 1);
            InSubDisplayChoiceIndex = PlayerPrefs.GetInt("InSubDisplayChoice", 1);
            MoveCompassSliderValue = PlayerPrefs.GetFloat("HUDMoveCompassSlider", -20f);
            SoftenHUDColourOutsideToggleValue = PlayerPrefsExtra.GetBool("SoftenHUDColourOutsideToggle", true);

            ShowOxygenToggleValue = PlayerPrefsExtra.GetBool("ShowOxygenToggle", true);

            ShowHullStrengthToggleValue = PlayerPrefsExtra.GetBool("ShowHullStrengthToggle", true);
            HullLowerLimitSliderValue = PlayerPrefs.GetFloat("HUDLowerLimitSlider", 5f);
            HullUpperLimitSliderValue = PlayerPrefs.GetFloat("HUDUpperLimitSlider", 10f);

            ShowCyclopsHullToggleValue = PlayerPrefsExtra.GetBool("ShowCyclopsHullToggle", true);

            ShowBiomeToggleValue = PlayerPrefsExtra.GetBool("ShowBiomeToggle", true);

            ShowWaterTempToggleValue = PlayerPrefsExtra.GetBool("SMLHelperShowWaterTempToggle", true);
            TempLowerLimitSliderValue = PlayerPrefs.GetFloat("TempLowerLimitSlider", 30f);
            TempUpperLimitSliderValue = PlayerPrefs.GetFloat("TempUpperLimitSlider", 45f);

            ShowClockToggleValue = PlayerPrefsExtra.GetBool("ShowClockToggle", true);
            ClockDisplayChoiceIndex = PlayerPrefs.GetInt("ClockDisplayChoice", 0);
            ClockGameSystemChoiceIndex = PlayerPrefs.GetInt("ClockGameSystemChoice", 0);

            ShowCoordsToggleValue = PlayerPrefsExtra.GetBool("ShowCoordsToggle", true);
        }
    }

    public class Options : ModOptions
    {
        public Options() : base("Better HUD Info <color=#999999FF>(restart game for compass move)</color>")
        {
            SliderChanged += Options_FontSizeSliderChanged;

            ChoiceChanged += Options_InBaseDisplayChoiceChanged;
            ChoiceChanged += Options_OutsideDisplayChoiceChanged;
            ChoiceChanged += Options_InSubDisplayChoiceChanged;
            SliderChanged += Options_MoveCompassSliderChanged;
            ToggleChanged += Options_SoftenHUDColourOutsideToggleChanged;

            ToggleChanged += Options_OxygenToggleChanged;

            ToggleChanged += Options_HullStrengthToggleChanged;
            SliderChanged += Options_HullLowerLimitSliderChanged;
            SliderChanged += Options_HullUpperLimitSliderChanged;

            ToggleChanged += Options_CyclopsHullToggleChanged;

            ToggleChanged += Options_BiomeToggleChanged;

            ToggleChanged += Options_WaterTempToggleChanged;
            SliderChanged += Options_TempLowerLimitSliderChanged;
            SliderChanged += Options_TempUpperLimitSliderChanged;

            ToggleChanged += Options_ClockToggleChanged;
            ChoiceChanged += Options_DisplayClockChoiceChanged;
            ChoiceChanged += Options_ClockGameSystemChoiceChanged;

            ToggleChanged += Options_CoordsToggleChanged;
        }

        public void Options_FontSizeSliderChanged(object sender, SliderChangedEventArgs e)
        {
            if (e.Id != "fontSizeSlider") return;
            Config.FontSizeSliderValue = Mathf.Floor(e.Value);
            PlayerPrefs.SetFloat("FontSizeSlider", Mathf.Floor(e.Value));
        }


        public void Options_InBaseDisplayChoiceChanged(object sender, ChoiceChangedEventArgs e)
        {
            if (e.Id != "displayInBaseHUDChoice") return;
            Config.InBaseDisplayChoiceIndex = e.Index;
            PlayerPrefs.SetInt("InBaseDisplayChoice", e.Index);
        }
        public void Options_OutsideDisplayChoiceChanged(object sender, ChoiceChangedEventArgs e)
        {
            if (e.Id != "displayOutsideHUDChoice") return;
            Config.OutsideDisplayChoiceIndex = e.Index;
            PlayerPrefs.SetInt("OutsideDisplayChoice", e.Index);
        }
        public void Options_InSubDisplayChoiceChanged(object sender, ChoiceChangedEventArgs e)
        {
            if (e.Id != "displayInSubHUDChoice") return;
            Config.InSubDisplayChoiceIndex = e.Index;
            PlayerPrefs.SetInt("InSubDisplayChoice", e.Index);
        }
        public void Options_MoveCompassSliderChanged(object sender, SliderChangedEventArgs e)
        {
            if (e.Id != "compassLimitSlider") return;
            Config.MoveCompassSliderValue = Mathf.Floor(e.Value);
            PlayerPrefs.SetFloat("HUDMoveCompassSlider", Mathf.Floor(e.Value));
        }
        public void Options_SoftenHUDColourOutsideToggleChanged(object sender, ToggleChangedEventArgs e)
        {
            if (e.Id != "softenHUDColourOutsideToggle") return;
            Config.SoftenHUDColourOutsideToggleValue = e.Value;
            PlayerPrefsExtra.SetBool("SoftenHUDColourOutsideToggle", e.Value);
        }


        public void Options_OxygenToggleChanged(object sender, ToggleChangedEventArgs e)
        {
            if (e.Id != "showOxygenToggle") return;
            Config.ShowOxygenToggleValue = e.Value;
            PlayerPrefsExtra.SetBool("ShowOxygenToggle", e.Value);
        }


        public void Options_HullStrengthToggleChanged(object sender, ToggleChangedEventArgs e)
        {
            if (e.Id != "showHullStrengthToggle") return;
            Config.ShowHullStrengthToggleValue = e.Value;
            PlayerPrefsExtra.SetBool("ShowHullStrengthToggle", e.Value);
        }
        public void Options_HullLowerLimitSliderChanged(object sender, SliderChangedEventArgs e)
        {
            if (e.Id != "hullLowerLimitSlider") return;
            Config.HullLowerLimitSliderValue = Mathf.Floor(e.Value);
            PlayerPrefs.SetFloat("HUDLowerLimitSlider", Mathf.Floor(e.Value));
        }
        public void Options_HullUpperLimitSliderChanged(object sender, SliderChangedEventArgs e)
        {
            if (e.Id != "hullUpperLimitSlider") return;
            Config.HullUpperLimitSliderValue = Mathf.Floor(e.Value);
            PlayerPrefs.SetFloat("HUDUpperLimitSlider", Mathf.Floor(e.Value));
        }


        public void Options_CyclopsHullToggleChanged(object sender, ToggleChangedEventArgs e)
        {
            if (e.Id != "showCyclopsHullToggle") return;
            Config.ShowCyclopsHullToggleValue = e.Value;
            PlayerPrefsExtra.SetBool("ShowCyclopsHullToggle", e.Value);
        }


        public void Options_BiomeToggleChanged(object sender, ToggleChangedEventArgs e)
        {
            if (e.Id != "showBiomeToggle") return;
            Config.ShowBiomeToggleValue = e.Value;
            PlayerPrefsExtra.SetBool("ShowBiomeToggle", e.Value);
        }


        public void Options_WaterTempToggleChanged(object sender, ToggleChangedEventArgs e)
        {
            if (e.Id != "showWaterTempInfoToggle") return;
            Config.ShowWaterTempToggleValue = e.Value;
            PlayerPrefsExtra.SetBool("SMLHelperShowWaterTempToggle", e.Value);
        }
        public void Options_TempLowerLimitSliderChanged(object sender, SliderChangedEventArgs e)
        {
            if (e.Id != "tempLowerLimitSlider") return;
            Config.TempLowerLimitSliderValue = Mathf.Floor(e.Value);
            PlayerPrefs.SetFloat("TempLowerLimitSlider", Mathf.Floor(e.Value));
        }
        public void Options_TempUpperLimitSliderChanged(object sender, SliderChangedEventArgs e)
        {
            if (e.Id != "tempUpperLimitSlider") return;
            Config.TempUpperLimitSliderValue = Mathf.Floor(e.Value);
            PlayerPrefs.SetFloat("TempUpperLimitSlider", Mathf.Floor(e.Value));
        }

        public void Options_ClockToggleChanged(object sender, ToggleChangedEventArgs e)
        {
            if (e.Id != "showClockToggle") return;
            Config.ShowClockToggleValue = e.Value;
            PlayerPrefsExtra.SetBool("ShowClockToggle", e.Value);
        }
        public void Options_DisplayClockChoiceChanged(object sender, ChoiceChangedEventArgs e)
        {
            if (e.Id != "displayClockChoice") return;
            Config.ClockDisplayChoiceIndex = e.Index;
            PlayerPrefs.SetInt("ClockDisplayChoice", e.Index);
        }
        public void Options_ClockGameSystemChoiceChanged(object sender, ChoiceChangedEventArgs e)
        {
            if (e.Id != "displayClockGameSystemChoice") return;
            Config.ClockGameSystemChoiceIndex = e.Index;
            PlayerPrefs.SetInt("ClockGameSystemChoice", e.Index);
        }

        public void Options_CoordsToggleChanged(object sender, ToggleChangedEventArgs e)
        {
            if (e.Id != "showCoordsToggle") return;
            Config.ShowCoordsToggleValue = e.Value;
            PlayerPrefsExtra.SetBool("ShowCoordsToggle", e.Value);
        }


        // Default values of the mod
        public override void BuildModOptions()
        {
            AddSliderOption("fontSizeSlider", "Font size (game defult is 30)", 10, 40, Config.FontSizeSliderValue);

            AddChoiceOption("displayInBaseHUDChoice", "HUD in base", new string[] { "All items 1 line", "All items 2 lines" }, Config.InBaseDisplayChoiceIndex);
            AddChoiceOption("displayOutsideHUDChoice", "HUD outside", new string[] { "All items 1 line", "All items 2 lines" }, Config.OutsideDisplayChoiceIndex);
            AddChoiceOption("displayInSubHUDChoice", "HUD in sub", new string[] { "All items 1 line", "All items 2 lines" }, Config.InSubDisplayChoiceIndex);
            AddSliderOption("compassLimitSlider", "Move compass down (if needed) by", -30, -10, Config.MoveCompassSliderValue);
            AddToggleOption("softenHUDColourOutsideToggle", "Soften HUD colour outside", Config.SoftenHUDColourOutsideToggleValue);

            AddToggleOption("showOxygenToggle", "Show oxygen", Config.ShowOxygenToggleValue);

            AddToggleOption("showHullStrengthToggle", "Show base hull strength", Config.ShowHullStrengthToggleValue);
            AddSliderOption("hullLowerLimitSlider", "Hull low stats colour change @", 1, 7, Config.HullLowerLimitSliderValue);
            AddSliderOption("hullUpperLimitSlider", "Hull high stats colour change @", 8, 15, Config.HullUpperLimitSliderValue);

            AddToggleOption("showCyclopsHullToggle", "Show Cyclops hull strength", Config.ShowCyclopsHullToggleValue);

            AddToggleOption("showBiomeToggle", "Show biome", Config.ShowBiomeToggleValue);

            AddToggleOption("showWaterTempInfoToggle", "Show water °C", Config.ShowWaterTempToggleValue);
            AddSliderOption("tempLowerLimitSlider", "°C low stats colour change @", 0, 40, Config.TempLowerLimitSliderValue);
            AddSliderOption("tempUpperLimitSlider", "°C high stats colour change @", 41, 50, Config.TempUpperLimitSliderValue);

            AddToggleOption("showClockToggle", "Show clock", Config.ShowClockToggleValue);
            AddChoiceOption("displayClockChoice", "12h / 24h", new string[] { "12h (am/pm)", "24h" }, Config.ClockDisplayChoiceIndex);
            AddChoiceOption("displayClockGameSystemChoice", "Game or system time", new string[] { "Game time", "System time" }, Config.ClockGameSystemChoiceIndex);

            AddToggleOption("showCoordsToggle", "Show coordinates", Config.ShowCoordsToggleValue);
        }
    }


    [HarmonyPatch(typeof(uGUI_PowerIndicator))]  // Patch for the uGUI_PowerIndicator class.
    [HarmonyPatch("UpdatePower")]        // The uGUI_PowerIndicator class's UpdatePower method.
    internal class uGUI_PowerIndicator_UpdatePower_Patch
    {
        // Helper method for processing and returning oxygen status
        public static string GetOxygen()
        {
            Player main = Player.main;
            StringBuilder stringBuilder = new StringBuilder();

            if (main.CanBreathe())
            {
                stringBuilder.Append("21%");
            }
            else
            {
                stringBuilder.Append("<color=red>");
                stringBuilder.Append("0%");
                stringBuilder.Append("</color>");
            }
            return stringBuilder.ToString();
        } // end GetOxygen()

        // Helper method for processing and returning time
        public static string GetTime()
        {
            StringBuilder stringBuilder = new StringBuilder();

            float dayScalar;
            int hours;
            int minutes;
            string ampm = "am";

            if (Config.ClockGameSystemChoiceIndex == 0)
            {
                dayScalar = DayNightCycle.main.GetDayScalar();
                hours = Mathf.FloorToInt(dayScalar * 24f);
                minutes = Mathf.FloorToInt(Mathf.Repeat(dayScalar * 24f * 60f, 60f));
            }
            else
            {
                DateTime now = DateTime.Now;
                hours = now.Hour;
                minutes = now.Minute;
            }

            stringBuilder.Append("TIME:");
            stringBuilder.Append(' ');

            if (Config.ClockDisplayChoiceIndex == 0)
            {
                if (hours > 12)
                {
                    hours -= 12;
                    ampm = "pm";
                }
            }

            stringBuilder.Append(hours.ToString());
            stringBuilder.Append(":");
            if (minutes < 10)
                stringBuilder.Append("0");
            stringBuilder.Append(minutes.ToString());
            stringBuilder.Append(' ');
            if (Config.ClockDisplayChoiceIndex == 0)
                stringBuilder.Append(ampm);

            return stringBuilder.ToString();
        }


        // Helper method for "softening" HUD color from bright white in base to 75% gray out of base during day, 85% at night (even less bright).
        public static string SoftenColours()
        {
            Player main = Player.main;
            DayNightCycle dayNightCycle = DayNightCycle.main;

            bool isDay = false;
            if (main != null && dayNightCycle != null)
            {
                isDay = dayNightCycle.IsDay();
            }
            StringBuilder stringBuilder = new StringBuilder();
            string colorStart = "<color=white>";

            if (Config.SoftenHUDColourOutsideToggleValue)
            {
                if (isDay)
                {
                    colorStart = "<color=#bfbfbf>";
                    stringBuilder.Append(colorStart);
                }
                else
                {
                    colorStart = "<color=#808080>";
                    stringBuilder.Append(colorStart);
                }
            }
            else
                stringBuilder.Append(colorStart);

            return stringBuilder.ToString();
        }

        // Helper method for processing and returning water temperature status
        public static string WaterTemp()
        {
            Player main = Player.main;
            StringBuilder stringBuilder = new StringBuilder();
            string colorStart = "<color=white>";
            string colorWhite = "<color=white>";
            string colorYellow = "<color=yellow>";
            string colorRed = "<color=red>";
            string colorEnd = "</color>";

            if (main != null)
            {
                DayNightCycle dayNightCycle = DayNightCycle.main;
                WaterTemperatureSimulation mainWaterTempSim = WaterTemperatureSimulation.main;
                bool isDay = dayNightCycle.IsDay();
                float waterTemp = 20f;

                if (mainWaterTempSim != null)
                {
                    if (main.IsPiloting() && main.IsInBase())
                    {
                        uGUI_CameraDrone thisuGUI_CameraDrone = uGUI_CameraDrone.main;
                        MapRoomCamera thisMapRoomCamera = thisuGUI_CameraDrone.GetCamera();
                        waterTemp = mainWaterTempSim.GetTemperature(thisMapRoomCamera.transform.position);
                    }                        
                    else
                        waterTemp = mainWaterTempSim.GetTemperature(main.transform.position);
                    
                    if (Config.SoftenHUDColourOutsideToggleValue)
                    {
                        if (main.IsPiloting() || !main.IsInside())
                        {
                            if (isDay)
                            {
                                if (waterTemp <= Mathf.Floor(Config.TempLowerLimitSliderValue))
                                    colorStart = "<color=#bfbfbf>";
                                else if (waterTemp > Mathf.Floor(Config.TempLowerLimitSliderValue) && waterTemp <= Mathf.Floor(Config.TempUpperLimitSliderValue))
                                    // colorStart = "<color=#ffff80>";
                                    colorStart = colorYellow;
                                else
                                    //colorStart = "<color=#ff8080>";
                                    colorStart = colorRed;
                                stringBuilder.Append(colorStart);
                            }
                            else
                            {
                                if (waterTemp <= Mathf.Floor(Config.TempLowerLimitSliderValue))
                                    colorStart = "<color=#808080>";                                    
                                else if (waterTemp > Mathf.Floor(Config.TempLowerLimitSliderValue) && waterTemp <= Mathf.Floor(Config.TempUpperLimitSliderValue))
                                    // colorStart = "<color=#ffffb3>";
                                    colorStart = colorYellow;
                                else
                                    // colorStart = "<color=#ffb3b3>";
                                    colorStart = colorRed;
                                stringBuilder.Append(colorStart);
                            }
                        }
                        else
                            stringBuilder.Append(colorStart);
                    }
                    else
                    {
                        if (waterTemp <= Mathf.Floor(Config.TempLowerLimitSliderValue))
                            colorStart = colorWhite;
                        else if (waterTemp > Mathf.Floor(Config.TempLowerLimitSliderValue) && waterTemp <= Mathf.Floor(Config.TempUpperLimitSliderValue))
                            colorStart = colorYellow;
                        else
                            colorStart = colorRed;
                        stringBuilder.Append(colorStart);
                    }

                    stringBuilder.Append("WATER:");
                    stringBuilder.Append(' ');
                    stringBuilder.Append(Mathf.RoundToInt(waterTemp).ToString());
                    stringBuilder.Append("°C");
                    stringBuilder.Append(colorEnd);
                }
            }
            return stringBuilder.ToString();
        }

        // Helper method for processing and returning where player is (Biome)
        public static string Biome()
        {
            Player main = Player.main;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("BIOME: ");
            if (main.IsPiloting() && main.IsInBase())
            {
                uGUI_CameraDrone thisuGUI_CameraDrone = uGUI_CameraDrone.main;
                MapRoomCamera thisMapRoomCamera = thisuGUI_CameraDrone.GetCamera();
                stringBuilder.Append(LargeWorld.main.GetBiome(thisMapRoomCamera.transform.position).ToUpper());
                // stringBuilder.Append(thisMapRoomCamera.transform.position);
            }
            else
                stringBuilder.Append(main.GetBiomeString().ToUpper());

            return stringBuilder.ToString();
        }


        // Change vanilla uGUI_PowerIndicator operation.
        [HarmonyPostfix]      // Harmony postfix
        public static void Postfix(uGUI_PowerIndicator __instance)
        {
            var cachedPower = Traverse.Create(__instance).Field("cachedPower").GetValue<int>();
            var cachedMaxPower = Traverse.Create(__instance).Field("cachedMaxPower").GetValue<int>();

            Player main = Player.main;
            if (main != null)
            {
                SubRoot currentSub = main.currentSub;
                StringBuilder stringBuilder = new StringBuilder();
                string colorStart = "<color=white>";
                string colorWhite = "<color=white>";
                string colorYellow = "<color=yellow>";
                string colorRed = "<color=red>";
                string colorEnd = "</color>";
                // float fontSize = 16f;
                // float fontSubScript = fontSize/2f;

                // Set font size. Default font size is 30.
                // stringBuilder.Append("<size=30>X</size>");
                // stringBuilder.Append("<size=32>X</size>");

                // stringBuilder.Append("<size=");
                // stringBuilder.Append(Config.FontSizeSliderValue.ToString());
                // stringBuilder.Append(">");

                // ################################################################################################
                // HUD when inside a base
                // ################################################################################################

                if (main.IsInBase())
                {
                    // Set font size
                    stringBuilder.Append("<size=");
                    stringBuilder.Append(Config.FontSizeSliderValue.ToString());
                    stringBuilder.Append(">");

                    // Show oxygen production status as per choice.
                    if (Config.ShowOxygenToggleValue && !main.IsPiloting())
                    {
                        stringBuilder.Append(colorStart);
                        // stringBuilder.Append("O<size=16>2</size>: ");
                        stringBuilder.Append("O<size=");
                        stringBuilder.Append((Config.FontSizeSliderValue/2f).ToString());
                        stringBuilder.Append(">2</size>: ");
                        stringBuilder.Append(GetOxygen());
                        stringBuilder.Append(" | ");
                        stringBuilder.Append(colorEnd);
                    }


                    // Show power in base as per default behaviour but colour coded.
                    if (!main.IsPiloting())
                        stringBuilder.Append(Language.main.GetFormat("HUDPowerStatus", cachedPower, cachedMaxPower));

                    // Show or hide hull strength on HUD in base as per choice.
                    if (Config.ShowHullStrengthToggleValue && !main.IsInSubmarine() && !main.IsPiloting())
                    {
                        BaseHullStrength thisBaseHullStrength = currentSub.GetComponent<BaseHullStrength>();
                        float totalBaseStrength = Mathf.RoundToInt(thisBaseHullStrength.GetTotalStrength());

                        if (totalBaseStrength <= Mathf.Floor(Config.HullLowerLimitSliderValue))
                            colorStart = "<color=red>";
                        else if (totalBaseStrength > Mathf.Floor(Config.HullLowerLimitSliderValue) && totalBaseStrength <= Mathf.Floor(Config.HullUpperLimitSliderValue))
                            colorStart = "<color=yellow>";
                        else
                            colorStart = "<color=white>";

                        if (Config.InBaseDisplayChoiceIndex == 0)
                            stringBuilder.Append(" | ");
                        else
                            stringBuilder.Append('\n');

                        stringBuilder.Append(colorStart);
                        stringBuilder.Append("HULL: ");
                        stringBuilder.Append(totalBaseStrength.ToString());
                        stringBuilder.Append(colorEnd);
                    }


                    // Show or hide clock on HUD in base as per choice.
                    if (Config.ShowClockToggleValue && !main.IsPiloting())
                    {
                        colorStart = "<color=white>";
                        stringBuilder.Append(colorStart);
                        if (Config.InBaseDisplayChoiceIndex == 0 || Config.ShowHullStrengthToggleValue)
                            stringBuilder.Append(" | ");
                        else
                            stringBuilder.Append('\n');

                        stringBuilder.Append(GetTime().ToString());
                        stringBuilder.Append(colorEnd);
                    }

                    // No need to show coordinates when in base
                    stringBuilder.Append("</size>");
                    __instance.text.text = stringBuilder.ToString();

                } // end if (main.IsInBase())


                // ################################################################################################
                // HUD when outside
                // ################################################################################################

                if (!main.IsInside())
                {
                    // This will turn on power HUD for our use out of base
                    __instance.text.enabled = true;


                    // Set font size
                    stringBuilder.Append("<size=");
                    stringBuilder.Append(Config.FontSizeSliderValue.ToString());
                    stringBuilder.Append(">");


                    // Show oxygen production status as per choice.
                    if (Config.ShowOxygenToggleValue && !main.IsUnderwater())
                    {
                        stringBuilder.Append(SoftenColours());
                        // stringBuilder.Append("O<size=16>2</size>: ");
                        stringBuilder.Append("O<size=");
                        stringBuilder.Append((Config.FontSizeSliderValue / 2f).ToString());
                        stringBuilder.Append(">2</size>: ");
                        stringBuilder.Append(GetOxygen());
                        stringBuilder.Append(" | ");
                        stringBuilder.Append(colorEnd);
                    }

                    stringBuilder.Append(SoftenColours());
                    stringBuilder.Append("OUTSIDE ");
                    stringBuilder.Append(colorEnd);


                    // Show or hide biome on HUD when out of base as per choice.
                    if (Config.ShowBiomeToggleValue)
                    {
                        stringBuilder.Append(SoftenColours());
                        stringBuilder.Append(Biome());
                        stringBuilder.Append(colorEnd);
                    }


                    // Show or hide temperature on HUD when out of base as per choice
                    if (Config.ShowWaterTempToggleValue && main.IsUnderwater())
                    {
                        // If needed, prepare for Display Water Temperature on HUD as per Hull Strength on HUD (to the right or below - 1 or 2 text lines).
                        stringBuilder.Append(SoftenColours());

                        // Display in single line.
                        if (Config.OutsideDisplayChoiceIndex == 0)
                        {
                            if (Config.ShowBiomeToggleValue)
                                stringBuilder.Append(" | ");
                        }
                        else // Display in double line.
                            stringBuilder.Append('\n');

                        stringBuilder.Append(WaterTemp());
                        stringBuilder.Append(colorEnd);
                    }


                    // Show or hide clock on HUD when out of base as per choice
                    if (Config.ShowClockToggleValue)
                    {
                        stringBuilder.Append(SoftenColours());

                        // Display in single line.
                        if (Config.OutsideDisplayChoiceIndex == 0)
                        {
                            if (Config.ShowBiomeToggleValue || Config.ShowWaterTempToggleValue)
                                stringBuilder.Append(" | ");
                        }
                        else // Display in double line.
                        {
                            if (Config.ShowWaterTempToggleValue && main.IsUnderwater())
                                stringBuilder.Append(" | ");
                            else
                                stringBuilder.Append('\n');
                        }
                        stringBuilder.Append(GetTime().ToString());
                        stringBuilder.Append(colorEnd);
                    }


                    // Show or hide coordinates on HUD when out of base as per choice.
                    if (Config.ShowCoordsToggleValue)
                    {
                        stringBuilder.Append(SoftenColours());

                        if (Config.OutsideDisplayChoiceIndex == 0 || Config.ShowWaterTempToggleValue || Config.ShowClockToggleValue)                            
                            stringBuilder.Append(" | ");

                        else
                            stringBuilder.Append('\n');

                        stringBuilder.Append(main.transform.position);
                        stringBuilder.Append(colorEnd); 
                    }

                    stringBuilder.Append("</size>");
                    __instance.text.text = stringBuilder.ToString();

                } // end if (!main.IsInside())


                // ################################################################################################
                // HUD when piloting
                // ################################################################################################

                // Player is piloting Seamoth or Prawn Suit
                if (main.IsPiloting() && !main.IsInSubmarine())
                {

                    // This will turn on power HUD for our use out of base.
                    __instance.text.enabled = true;


                    // Set font size
                    stringBuilder.Append("<size=");
                    stringBuilder.Append(Config.FontSizeSliderValue.ToString());
                    stringBuilder.Append(">");


                    // Show oxygen production status as per choice.
                    if (Config.ShowOxygenToggleValue)
                    {
                        stringBuilder.Append(SoftenColours());
                        if (main.IsInBase())
                            stringBuilder.Append("BASE ");
                        // stringBuilder.Append("O<size=16>2</size>: ");
                        stringBuilder.Append("O<size=");
                        stringBuilder.Append((Config.FontSizeSliderValue / 2f).ToString());
                        stringBuilder.Append(">2</size>: ");
                        stringBuilder.Append(GetOxygen());
                        stringBuilder.Append(" | ");
                        stringBuilder.Append(colorEnd);
                    }

                    stringBuilder.Append(SoftenColours());

                    if (main.IsInBase())
                        stringBuilder.Append("CAMERA ");
                    else
                        stringBuilder.Append("PILOTING ");

                    stringBuilder.Append(colorEnd);


                    // Show or hide Biome on HUD when piloting as per choice.
                    if (Config.ShowBiomeToggleValue)
                    {
                        stringBuilder.Append(SoftenColours());
                        stringBuilder.Append(Biome());
                        stringBuilder.Append(colorEnd);
                    }


                    // Show or hide temperature on HUD when piloting a "camera" as per choice ("vehicles" have their own temp reader bottom right).
                    if (Config.ShowWaterTempToggleValue && main.IsPiloting() && main.IsInBase())
                    {
                        // If needed, prepare for display water temperature on HUD as per hull strength on HUD (to the right or below - 1 or 2 lines).
                        stringBuilder.Append(SoftenColours());

                        if (Config.InSubDisplayChoiceIndex == 0)
                        {
                            if (Config.ShowBiomeToggleValue)
                                stringBuilder.Append(" | ");
                        }
                        else
                            stringBuilder.Append('\n');

                        stringBuilder.Append(WaterTemp());
                        stringBuilder.Append(colorEnd);
                    }


                    // Show or hide clock on HUD when piloting or using Scanner room cameras as per choice.
                    if (Config.ShowClockToggleValue)
                    {
                        stringBuilder.Append(SoftenColours());

                        if (main.IsInBase()) // Piloting "camera" from the base.
                        {
                            if (Config.InSubDisplayChoiceIndex == 0) // If we need to display on single line.
                            {
                                if (Config.ShowBiomeToggleValue || Config.ShowWaterTempToggleValue)
                                    stringBuilder.Append(" | ");
                                else
                                    stringBuilder.Append('\n');
                            }
                            else // If we need to display on double line.
                            {
                                if (Config.ShowWaterTempToggleValue)
                                    stringBuilder.Append(" | ");
                                else
                                    stringBuilder.Append('\n');
                            }
                        }
                        else // Piloting vehicle (Seamoth or Prawn Suit).
                        {
                            if (Config.InSubDisplayChoiceIndex == 0) // If we need to display on single line.
                            {
                                if (Config.ShowBiomeToggleValue)
                                    stringBuilder.Append(" | ");
                                else
                                    stringBuilder.Append('\n');
                            }
                            else // If we need to display on double line.
                            {
                                stringBuilder.Append('\n');
                            }
                        }

                        stringBuilder.Append(GetTime().ToString());
                        stringBuilder.Append(colorEnd);
                    }


                    // Show or hide coordinates on HUD when when piloting or using Scanner room cameras as per choice.
                    if (Config.ShowCoordsToggleValue)
                    {
                        stringBuilder.Append(SoftenColours());

                        if (main.IsInBase()) // Piloting "camera" from the base
                        {
                            if (Config.InSubDisplayChoiceIndex == 0) // If we need to display on single line.
                            {
                                    stringBuilder.Append(" | ");
                            }
                            else // If we need to display on double line.
                            {
                                if (Config.ShowWaterTempToggleValue || Config.ShowClockToggleValue)
                                    stringBuilder.Append(" | ");
                                else
                                    stringBuilder.Append('\n');
                            }

                            uGUI_CameraDrone thisuGUI_CameraDrone = uGUI_CameraDrone.main;
                            MapRoomCamera thisMapRoomCamera = thisuGUI_CameraDrone.GetCamera();
                            stringBuilder.Append(thisMapRoomCamera.transform.position);
                        }
                        else // Piloting vehicle (Seamoth or Prawn Suit).
                        {
                            if (Config.InSubDisplayChoiceIndex == 0) // If we need to display on single line
                            {
                                    stringBuilder.Append(" | ");
                            }
                            else // If we need to display on double line
                            {
                                if (Config.ShowClockToggleValue)
                                    stringBuilder.Append(" | ");
                                else
                                    stringBuilder.Append('\n');
                            }
                            stringBuilder.Append(main.transform.position);
                        }

                        stringBuilder.Append(colorEnd);

                    }

                    stringBuilder.Append("</size>");
                    __instance.text.text = stringBuilder.ToString();

                } // end if (main.IsPiloting() && !main.IsInSubmarine())


                // ################################################################################################
                // HUD when in Cyclops
                // ################################################################################################

                if (main.IsInSubmarine())
                {
                    // This will turn on Power HUD for our use out of base.
                    __instance.text.enabled = true;
                    // Prepare for special case when player uses Cyclops cameras.
                    CyclopsExternalCams thisCyclopsExternalCams = currentSub.GetComponentInChildren<CyclopsExternalCams>();
                    bool isUsingCamera = thisCyclopsExternalCams.GetUsingCameras();
                    CyclopsHelmHUDManager thisCyclopsHelmHUDManager = currentSub.GetComponentInChildren<CyclopsHelmHUDManager>();


                    // Set font size
                    stringBuilder.Append("<size=");
                    stringBuilder.Append(Config.FontSizeSliderValue.ToString());
                    stringBuilder.Append(">");


                    // #################################
                    // Show oxygen status as per choice.

                    if (Config.ShowOxygenToggleValue)
                    {
                        if (main.IsPiloting())
                            colorStart = SoftenColours();
                        else
                            colorStart = colorWhite;

                        stringBuilder.Append(colorStart);
                        // stringBuilder.Append("O<size=16>2</size>: ");
                        stringBuilder.Append("O<size=");
                        stringBuilder.Append((Config.FontSizeSliderValue / 2f).ToString());
                        stringBuilder.Append(">2</size>: ");
                        stringBuilder.Append(GetOxygen());
                        stringBuilder.Append(colorEnd);
                    }

                    // ###################################################################################
                    // When in Cyclops (not piloting) or when using cameras.
                    // Show Power in Cyclops - (mimic default behaviour as per base but give charge in %).
                    // Also show Cyclops health and depth as per choice in %.
                    if (!main.IsPiloting() || (main.IsPiloting() && isUsingCamera))
                    {
                        float thisPower = currentSub.powerRelay.GetPower() / currentSub.powerRelay.GetMaxPower();

                        if (thisPower < 0)
                            thisPower = 0f;

                        if (thisPower * 100f <= 33f)
                            colorStart = colorRed;
                        else if (thisPower * 100f > 33f && thisPower * 100f <= 66f)
                            colorStart = colorYellow;
                        else
                        {
                            if (main.IsPiloting())
                                colorStart = SoftenColours();
                            else
                                colorStart = colorWhite;
                        }

                        // ############################
                        // Display Cyclops charge in %.
                        stringBuilder.Append(colorStart);
                        if (Config.ShowOxygenToggleValue)
                            stringBuilder.Append(" | ");
                        stringBuilder.Append("CYCLOPS");

                        if (Config.InSubDisplayChoiceIndex == 0)
                        {
                            stringBuilder.Append(" ");
                        }
                        else
                        {
                            if (!Config.ShowCyclopsHullToggleValue && !Config.ShowBiomeToggleValue && !Config.ShowWaterTempToggleValue && !Config.ShowClockToggleValue)
                                stringBuilder.Append('\n');
                            else
                                stringBuilder.Append(" ");
                        }                            

                        stringBuilder.Append("CHARGE: ");
                        stringBuilder.Append(Mathf.CeilToInt(thisPower * 100f).ToString());
                        stringBuilder.Append('%');
                        if (!main.IsPiloting())
                        {
                            if (!Config.ShowOxygenToggleValue && Config.ShowCyclopsHullToggleValue && !Config.ShowBiomeToggleValue && !Config.ShowWaterTempToggleValue && !Config.ShowClockToggleValue)
                                stringBuilder.Append('\n');
                            stringBuilder.Append(colorEnd);
                        }


                        // #########################################
                        // Display hull strength in % as per choice.
                        if (Config.ShowCyclopsHullToggleValue)
                        {
                            LiveMixin livecomponent = currentSub.GetComponent<LiveMixin>();
                            float thisHealth = livecomponent.GetHealthFraction();

                            if (thisHealth * 100f <= 33f)
                                colorStart = colorRed;
                            else if (thisHealth * 100f > 33f && thisHealth * 100f <= 66f)
                                colorStart = colorYellow;
                            else
                            {
                                if (main.IsPiloting())
                                    colorStart = SoftenColours();
                                else
                                    colorStart = colorWhite;
                            }

                            stringBuilder.Append(colorStart);
                            stringBuilder.Append(" HULL: ");
                            stringBuilder.Append(Mathf.RoundToInt(thisHealth * 100f).ToString());
                            stringBuilder.Append('%');
                            stringBuilder.Append(colorEnd);
                        } // end if (Config.ShowCyclopsHullToggleValue)

                        // #####################################################################
                        // Display depth and crush depth only when in camera mode as per choice.
                        if (isUsingCamera)
                        {
                            int currentDepth = Mathf.RoundToInt(thisCyclopsHelmHUDManager.crushDamage.GetDepth());
                            int crushDamage = Mathf.RoundToInt(thisCyclopsHelmHUDManager.crushDamage.crushDepth);

                            if (currentDepth >= (crushDamage - 100))
                                colorStart = colorRed;
                            else if (currentDepth <= (crushDamage - 100) && currentDepth >= (crushDamage - 200))
                                colorStart = colorYellow;
                            else
                                colorStart = SoftenColours();

                            stringBuilder.Append(colorStart);
                            stringBuilder.Append(" DEPTH: ");
                            stringBuilder.Append(currentDepth.ToString());
                            stringBuilder.Append(" / ");
                            stringBuilder.Append(crushDamage.ToString());
                            stringBuilder.Append("m");
                            stringBuilder.Append(colorEnd);
                        } // end if (isUsingCamera)

                    } // end if (!main.IsPiloting() || (main.IsPiloting() && isUsingCamera))

                    // ########################################################
                    // Show or hide Biome on HUD when in Cyclops as per choice.
                    if (Config.ShowBiomeToggleValue)
                    {
                        if (main.IsPiloting())
                            colorStart = SoftenColours();
                        else
                            colorStart = colorWhite;

                        stringBuilder.Append(colorStart);

                        if (Config.InSubDisplayChoiceIndex == 1) // if HUD should be on 2 lines.
                        {
                            if (main.IsPiloting()) // Cyclops or cameras.
                            {
                                if (Config.ShowOxygenToggleValue || isUsingCamera)
                                    stringBuilder.Append(" | ");
                            }
                            else // When not piloting.
                            {
                                if (!Config.ShowWaterTempToggleValue && !Config.ShowClockToggleValue) // If neither temperature nor time are shown, put Biome on a new line.
                                    stringBuilder.Append('\n');
                                else
                                    stringBuilder.Append(" | ");
                            }

                        }
                        else // If HUD should be on 1 line only.
                        {
                            if (main.IsPiloting())
                            {
                                if (Config.ShowOxygenToggleValue)
                                    stringBuilder.Append(" | ");
                            }
                            else
                                stringBuilder.Append(" | ");
                        }
                        
                        stringBuilder.Append(Biome());
                        stringBuilder.Append(colorEnd);
                    } // end if (Config.ShowBiomeToggleValue)

                    // ##############################################################
                    // Show or hide Temperature on HUD when in Cyclops as per choice.
                    if (Config.ShowWaterTempToggleValue)
                    {
                        if (main.IsPiloting())
                            colorStart = SoftenColours();
                        else
                            colorStart = colorWhite;

                        stringBuilder.Append(colorStart);
                        if (Config.InSubDisplayChoiceIndex == 0)
                            stringBuilder.Append(" | ");
                        else
                            stringBuilder.Append('\n');
                        stringBuilder.Append(WaterTemp());
                        stringBuilder.Append(colorEnd);
                    } // end if (Config.ShowWaterTempToggleValue)

                    // ########################################################
                    // Show or hide Clock on HUD when in Cyclops as per choice.
                    if (Config.ShowClockToggleValue)
                    {
                        if (main.IsPiloting())
                            colorStart = SoftenColours();
                        else
                            colorStart = colorWhite;

                        stringBuilder.Append(colorStart);
                        if (Config.InSubDisplayChoiceIndex == 0)
                            stringBuilder.Append(" | ");
                        else
                        {
                            if (Config.ShowWaterTempToggleValue)
                                stringBuilder.Append(" | ");
                            else
                                stringBuilder.Append('\n');
                        }
                        stringBuilder.Append(GetTime().ToString());
                        stringBuilder.Append(colorEnd);
                    }

                    // ########################################################################################
                    // Show or hide coordinates on HUD when in piloting Cyclops or using cameras as per choice.
                    if (Config.ShowCoordsToggleValue && main.IsPiloting())
                    {
                        stringBuilder.Append(SoftenColours());
                        if (Config.InSubDisplayChoiceIndex == 0)
                            stringBuilder.Append(" | ");
                        else
                        {
                            if (Config.ShowWaterTempToggleValue || Config.ShowClockToggleValue)
                                stringBuilder.Append(" | ");
                            else
                                stringBuilder.Append('\n');
                        }
                        stringBuilder.Append(main.transform.position);
                        stringBuilder.Append(colorEnd);
                    }
                    stringBuilder.Append("</size>");
                    __instance.text.text = stringBuilder.ToString();
                } // end if (main.IsInSubmarine())
            } // if (main != null)
        } // uGUI_PowerIndicator


        [HarmonyPatch(typeof(uGUI_SceneHUD))] // Patch for the uGUI_SceneHUD class.
        [HarmonyPatch("Initialize")]        // The uGUI_SceneHUD class' Initialize method.
        public static class uGUI_SceneHUD_Initialize_Patch
        {
            private static readonly FieldInfo SceneHud_initialized = typeof(uGUI_SceneHUD).GetField("_initialized", BindingFlags.Instance | BindingFlags.NonPublic);
            private static bool preInitialized;
            private static bool initialized;

            // Move Compass on HUD down if required as per options.
            [HarmonyPrefix]
            private static bool Prefix(uGUI_SceneHUD __instance)
            {
                if (Config.ShowHullStrengthToggleValue || Config.ShowBiomeToggleValue || Config.ShowWaterTempToggleValue || Config.ShowClockToggleValue)
                    uGUI_SceneHUD_Initialize_Patch.preInitialized = (bool)uGUI_SceneHUD_Initialize_Patch.SceneHud_initialized.GetValue(__instance);
                return true;
            }

            [HarmonyPostfix]
            private static void Postfix(uGUI_SceneHUD __instance)
            {
                if (Config.ShowHullStrengthToggleValue || Config.ShowBiomeToggleValue || Config.ShowWaterTempToggleValue || Config.ShowClockToggleValue)
                {
                    uGUI_SceneHUD_Initialize_Patch.initialized = (bool)uGUI_SceneHUD_Initialize_Patch.SceneHud_initialized.GetValue(__instance);
                    bool flag = !uGUI_SceneHUD_Initialize_Patch.preInitialized && uGUI_SceneHUD_Initialize_Patch.initialized;
                    if (flag)
                    {
                        Transform transform = __instance.transform.Find("Content");
                        if (transform != null)
                        {
                            RectTransform rectTransform = transform.Find("DepthCompass") as RectTransform;
                            if (rectTransform != null)
                            {
                                rectTransform.anchoredPosition += new Vector2(0, Mathf.Floor(Config.MoveCompassSliderValue));
                            }
                        }
                    }
                }
            }
        }


        [HarmonyPatch(typeof(uGUI_PowerIndicator))]  // Patch for the uGUI_PowerIndicator class.
        [HarmonyPatch("IsPowerEnabled")]        // The uGUI_PowerIndicator class' IsPowerEnabled method.
        internal class uGUI_PowerIndicator_IsPowerEnabled_Patch
        {
            [HarmonyPostfix]
            private static void Postfix(bool __result)
            {
                Player main = Player.main;
                // Enable HUD when not in base.
                if (main != null && !main.IsInBase())
                {
                    __result = true;
                }
                __result = false;
            }
        }
    }
}