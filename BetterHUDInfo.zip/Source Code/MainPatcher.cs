﻿using System;
using System.IO;
using System.Reflection;
using Harmony;
using SMLHelper;
using SMLHelper.V2.Handlers;

// You can use this file almost as-is. Just change the marked lines below. This will be the main file of each mod that tells Harmony to load your changes.
namespace BetterHUDInfo     // Change this line to match your mod.
{
    public class MainPatcher
    {
        public static void Patch()
        {
            var harmony = HarmonyInstance.Create("com.mimes.subnautica.betterhudinfo");   // Change this line to match your mod. 
            harmony.PatchAll(Assembly.GetExecutingAssembly());
            Config.Load();
            OptionsPanelHandler.RegisterModOptions(new Options());
        }

    }
}