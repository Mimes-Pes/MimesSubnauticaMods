
BetterHUDInfo - 1.0.1 Beta

:: VERSION HISTORY ::
1.0.0 - initial release
1.0.0b - packaged with unzip folder
1.0.1 Beta - added font size slider

:: FOREWORD ::
Heartfelt personal welcome from 
Professor Mimes Pes, Chief Scientific Officer
Alterra Corporation

Dear Alterra Employees

As you no doubt already know, my staff have been working hard and presented you over the years with many wonderful inventions called "mods". I am delighted to offer you my third improvement, alias "mod". In an event of an accident and forced planetary landing, central nervous system of the subject often fails to convey correct information about water temperature, oxygen status and the like. In addition, expanding base without knowing its hull strength beforehand can cause hull breach with dire consequences. Moonpool Display and Repair helps somewhat, but this mod lets you to see hull strength at all times, even when adding windows in furthermost rooms from Moonpool. Similarly, detailed information about status and location of Scanner Room cameras, or every aspect of your Cyclops while piloting by using Cyclops camera can aid in an absolute precision in sticky situations. Your HUD will change automatically and show you what you need: in the base, outside / swimming, in your vehicles, in Cyclops and most importantly while using Scanner Room cameras and piloting Cyclops via any of its 3 cameras. And lastly, you will be able to change values for warning displays as well as customise (display or hide) any and all items on your HUD. The plan is to improve this mod prototype by having craftable upgrade which will be used in a similar way to compass:

I understand that some employees may feel more information on the HUD may be "immersion" breaking. Just remember that when in an alien planet's ocean, being viewed via your PC monitor screen, the only reliable CNS signal is via the HUD :o)


:: SUMMARY ::
This mod greatly expands functionality of your HUD. It dynamically changes depending on your location and status:
� Inside the base
� Outside swimming or walking
� While piloting
� Vehicles (Seamoth and Prawn)
� Scanner Room Cameras
� In Cyclops
� Walking around in Cyclops
� Piloting
� Piloting and using Cyclops cameras


:: REQUIREMENTS ::
� Should work on all versions of Subnautica
� QModManager is required
� SMLHelper is required


:: FEATURES ::
Items displayed on the HUD:

	� Inside the base:
		� Oxygen production status
		� Power (as per vanilla)
		� Base hull strength
		� Time - game or system time in 12 hour (am/pm) or 24 hour format
	� Outside swimming or walking
		� Biome
		� Water temperature
		� Time - game or system time in 12 hour (am/pm) or 24 hour format
		� Player coordinates
	� While piloting vehicles (Seamoth and Prawn)
		� Oxygen production status
		� Biome
		� Time - game or system time in 12 hour (am/pm) or 24 hour format
		� Player coordinates
	� While piloting Scanner Room cameras
		� Scanner Room oxygen production status
		� Biome
		� Water temperature around camera
		� Time - game or system time in 12 hour (am/pm) or 24 hour format
		� Camera coordinates
	� In Cyclops while walking around
		� Cyclops oxygen production status
		� Cyclops batteries charge status (in %)
		� Cyclops hull strength status (in %)
		� Cyclops biome location
		� Cyclops water temperature
		� Time - game or system time in 12 hour (am/pm) or 24 hour format
		� Cyclops coordinates
	� In Cyclops piloting
		� Cyclops oxygen production status
		� Cyclops biome location
		� Cyclops water temperature
		� Time - game or system time in 12 hour (am/pm) or 24 hour format
		� Cyclops coordinates
	� Piloting Cyclops and using Cyclops cameras
		� Cyclops oxygen production status
		� Cyclops batteries charge status (in %)
		� Cyclops hull strength status (in %)
		� Cyclops current / maximum depth
		� Cyclops biome location
		� Cyclops water temperature
		� Time - game or system time in 12 hour (am/pm) or 24 hour format
		� Cyclops coordinates


:: INSTALLATION ::
� Make sure you have both required mods installed first.
	� QModManager?
	� SMLHelper??
� Extract the zip archive into your QMods folder.
� Ensure in your QMods folder you have a folder named BetterHUDInfo.


:: USEAGE ::
Better HUD Info mod is fully customisable:

In Subnautica main screen click on "Options".
Click on "Mods" button.
Scroll down to "Better HUD Info" section.
Modifiers (options):

	� Font size - adjusts font size from 10 to 40, game default is 30.
	� HUD in base - choose to display HUD on 1 or 2 lines when in base.
	� HUD outside - choose to display HUD on 1 or 2 lines when outside.
	� HUD in sub - choose to display HUD on 1 or 2 lines when in a sub.
	� Move compass down (if needed) by - sets the position of compass in pixels below vanilla position for 2 line display. Requires game restart.
	� Soften HUD colour outside - "softens" colour of HUD from white to 75% grey out of base during day, 85% at night (even less bright).
	� Show oxygen - shows or hides oxygen production status - very useful with FC Studios oxygen mods and refillable oxygen tanks.
	� Show base hull strength - shows or hides display of base strength in units.
	� Hull low stats colour change - set value below which hull strength is shown in red.
	� Hull high stats colour change - set value above which hull strength is shown in white.
	� Show Cyclops hull strength - shows or hides hull strength in %.
	� Show biome - shows or hides biome name.
	� Show water �C - shows or hides water temperature.
	� �C low stats colour change - set value below which water temperature is shown in red.
	� �C high stats colour change - set value above which water temperature is shown in white.
	� Show clock - show or hide time
	� 12h / 24h - shows time as ?12 hour clock (am/pm) or ?24 hour clock
	� Game or system time - shows Game time which displays time as per game or System time which shows real world time
	� Show coordinates - shows or hides current player coordinates, in Scanner Room camera case camera coordinates


::  KNOWN ISSUES ::
� May not work correctly if used with mods which add repair function to Moonpool
� Tested on Subnautica "Apr-2018 60026" and "Jun-2020 65786"


::  CREDITS ::
� Professor Mimes Pes, Chief Scientific Officer, Altera Corporation


::  ADDENDUM ::

This mod is dedicated to the modding community and to amazing modders listed below and their sharing spirit. Without these mods playing Subnautica for me just would not be the same.


Thank you to (in alphabetical order):

aceredi & Musashi for Running With Tools 
ahk1221 for ToggleMachines, SeamothStorageAccess & Base Light Switch
AlexejheroYTB for Scuba Manifold
Andreadev for Deep Engine MK1
Anomaex for Prawn Suit Torpedo Display, Universal Charging Module & Explosive Torpedo
DarthStarbrow for Better Scanner Room
DaWrecka for Ingredients from Scanning
DragonS315 for NoBattery
Fenolphthalien for Base Clocks
gurrenm3 for Seaglide Sprinting
LukeWCS for QMod SAM
M3dicCookie for Replenish ReactorRods
metious for Seamoth Brine Resistance & Vehicle Piloting under the Brine Fix
Mikjaw for FreeLook
MrPurple6411 for SeamothThermal & More Seamoth Depth
nellia for Bio Batteries
oldark1 for Modding Tutorial, Red Baron & Warp Shield
PPVVDD for Defabricator & Radial tabs
randyknapp for various awesome mods
Remodor for Vehicles Improved, Vehicle Lights Improved & Power Modifier
senna7608 for all Seamoth, Prawn & Cyclops mods
SeraphimRisen for NitrogenMod
vps2600 for Variety Battery Pack
WhoTnT for Anisotropic Fix
Xilni for SwimChargeInventory & PrawnSolar
Yamitatsu for Better Vehicle Storage
zorgesho for all Console Improved, Prawn upgrades & Debris Recycling


And an extra special thanks to (in alphabetical order):

FC Studios for unbelievable set of mods
newman55 for map, oxygen tanks and inventory mods
OSubMarin for Cyclops Docking Mod and
PrimeSonic for QModManager 4, SMLHelper, MoreCyclopsUpgrades with all modules, CustomCraft2, CustomBatteries, Upgraded Vehicles


Thank you for your interest.

With kind regards,

Yours sincerely

Professor Mimes Pes, Chief Scientific Officer
Alterra Corporation